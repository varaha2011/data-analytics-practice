## Data Set Overview

> Name: IOLP Buildings.xlsx (renamed to iolpBuildings.xlsx within my project for the sake of simplicity)
> Dimensions: 7,758 Observations, 18 Variables
> Each observation represents one government building.
> Downloaded on October Third, 2026 (10/3/2026).

## Dimensions of Data Set
> 7,758 Observations, 18 Variables.

## Source of Data Set
> Website name: Data.gov
> [Direct Link to Source of Data](https://catalog.data.gov/dataset/inventory-of-owned-and-leased-properties-iolp)
> *NOTE:* This source was recently updated on November 13th. The data file now there likely has data that differs from the data set used in my project.