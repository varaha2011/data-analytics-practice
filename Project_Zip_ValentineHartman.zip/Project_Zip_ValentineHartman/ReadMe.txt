Name: Valentine Hartman
Project: Identifying Patterns In Data Regarding Government Buildings

Overview of Folder Contents:

Data: A markdown file containing a description of the properties of the data set I used in my project, as well as the data set itself in the form of a .xlsx file.

Proposal: My initial project proposal. My final project slightly differs from the details presented here.

Project: A .Html file and .Rmd file of my 5th deliverable, which goes over all of my findings and the bulk of my project.

Presentation: A powerpoint presentation that analyzes and presents some of the most noteworthy findings from my project​.

Packages to install for my report:

The R packages "ggplot2," "dplyr," "tidyr," and "plotly" are required to properly run the .Html of my report.